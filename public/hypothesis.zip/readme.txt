THE STRIPE HYPOTHESIS

Doc Leo has packed an entire experiment into one ZIP. Gwinn packed the packing list.

Keep all files together. Open HYPO.GAM with a compatible Game-Maker player,
or choose this ZIP in the browser player. The archive contains game data;
use the player of your choice. HELP.TXT has the controls.

See LICENSE.TXT, NOTICE.TXT, and CREDITS.TXT for credits and licensing.
